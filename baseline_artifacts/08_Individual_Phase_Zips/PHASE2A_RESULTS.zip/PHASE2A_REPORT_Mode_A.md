# Phase 2A — Statistical Validation & Quality Assessment Report

**Project Title:** Robust Crop Recommendation Using Realistic Synthetic Data with TabNet and Explainable AI
**Phase:** Phase 2A: Statistical Validation & Quality Assessment
**Version:** 1.1.2-MultiMode-Validated
**Timestamp (UTC):** 2026-10-19 02:13:43

---

## 1. Objective
The primary objective of **Phase 2A** is to determine quantitatively whether the synthetic dataset (`SYNTHETIC_CROP_DATA_MASTER.csv`, generated via Class-Conditional Empirical Gaussian-Rank Copula with Agricultural Constraints in Phase 1) statistically resembles the authentic real training dataset (`REAL_TRAIN.csv`).

This phase establishes foundational statistical fidelity, correlation structure preservation, and data integrity prior to downstream machine learning model training (Phase 2B).

---

## 2. Datasets
- **Primary Foundation (REAL_TRAIN):** 1,760 observations across 22 canonical crop classes (80% stratified partition).
- **Synthetic Master (SYNTHETIC_CROP_DATA_MASTER):** Synthetic observations across 22 crop classes.
- **Quarantined Evaluation Set (REAL_TEST):** 440 observations (20% partition). **Strict experimental isolation was maintained; REAL_TEST was not used for any statistical comparison or reference calibration.**

---

## 3. Statistical Methods
1. **Marginal Moment & Quantile Comparison:** Mean, Standard Deviation, Median, and Interquartile Ranges (IQR) computed per feature.
2. **Distributional Distance Metrics:** Two-sample Kolmogorov-Smirnov (KS) test with Benjamini-Hochberg (FDR) adjustment, and 1D Wasserstein distance (Earth Mover's Distance).
3. **Correlation Matrix Preservation:** Pearson correlation matrix error analysis evaluated via Mean Absolute Error (MAE), Frobenius Norm distance, and element-wise difference heatmaps.
4. **Leakage & Memorization Screening:** Cryptographic hashing and coordinate matching at full 8-decimal, 4-decimal, and 3-decimal precision.
5. **Nearest-Neighbor Geometric Similarity:** Standardized Euclidean distance distributions (Z-score normalized on REAL_TRAIN) comparing synthetic-to-real distances against the real-to-real internal baseline.

---

## 4. Global Distribution Fidelity
Summary of global moment alignment across all 7 canonical features:

| Feature | Real Mean | Synthetic Mean | Rel. Mean Diff (%) | Real SD | Synthetic SD | KS Stat | KS FDR q-val | Wasserstein Dist |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **N** | 50.48 | 50.54 | 0.12% | 36.93 | 36.87 | 0.0135 | 1.0000e+00 | 0.1842 |
| **P** | 53.37 | 53.37 | 0.00% | 33.11 | 33.08 | 0.0134 | 1.0000e+00 | 0.1147 |
| **K** | 48.18 | 48.19 | 0.03% | 50.64 | 50.62 | 0.0224 | 1.0000e+00 | 0.0529 |
| **temperature** | 25.59 | 25.61 | 0.06% | 5.03 | 5.00 | 0.0035 | 1.0000e+00 | 0.0241 |
| **humidity** | 71.50 | 71.49 | 0.01% | 22.29 | 22.26 | 0.0030 | 1.0000e+00 | 0.0375 |
| **ph** | 6.47 | 6.47 | 0.02% | 0.78 | 0.77 | 0.0048 | 1.0000e+00 | 0.0057 |
| **rainfall** | 103.32 | 103.34 | 0.02% | 54.63 | 54.48 | 0.0029 | 1.0000e+00 | 0.1579 |

*Note on KS p-values:* Because large synthetic sample sizes provide extreme statistical power, negligible practical deviations yield small p-values. Distributional fidelity is primarily supported by the low Wasserstein distances and bounded relative mean differences.

---

## 5. Per-Crop Fidelity
A complete breakdown across all 154 crop-feature combinations is exported in `PHASE2A_PER_CROP_VALIDATION.csv`. Class-conditional empirical copulas successfully captured the distinct bioclimatic requirements for each crop (e.g., Apple low-temperature regime vs. Banana high-humidity regime).

---

## 6. Correlation Preservation
- **Correlation Matrix Mean Absolute Error (MAE):** `0.00084`
- **Frobenius Norm Distance:** `0.00789`
- **Maximum Absolute Correlation Error:** `0.00325`

The correlation matrices demonstrated structural alignment, confirming that non-linear inter-feature dependencies (e.g., Temperature–Humidity interactions, Soil N–P balances) were preserved.

---

## 7. Class Balance
The synthetic dataset provides an exact balanced quota across all 22 crops, rectifying minor sample variations in real-world collections while maintaining equal statistical representation.

---

## 8. Synthetic Data Diversity
- **Total Synthetic Observations:** `165,000`
- **Unique Synthetic Instances:** `165,000` (`100.00%`)
- **Exact Intra-Synthetic Duplicates:** `0`
- **Statistical Dispersion:** Variance and IQR ratios remain close to 1.0 across all 7 features, verifying that synthetic generation avoided mode collapse without inflating variance beyond natural agricultural bounds.

---

## 9. Physical Plausibility
All synthetic observations strictly satisfied universal agronomic physical bounds:
- Soil N, P, K >= 0
- Aqueous pH between 0 and 14
- Relative Humidity between 0% and 100%
- Precipitation / Rainfall >= 0
- Thermodynamic Temperature > -273.15 °C

---

## 10. Leakage / Memorization Analysis
- **Exact Matches (Synthetic <-> REAL_TRAIN):** `0` (`0.00000%`)
- **3-Decimal Full-Record Matches:** `0` (`0.00000%`)
- **Intra-Synthetic 4-Decimal Duplicates:** `0` (`0.00000%`)

*Scientific Finding:* No evidence of exact row memorization or nearest-point replication was detected.

---

## 11. Nearest-Neighbor Analysis
Standardized Euclidean distance analysis (Z-scores parameterized on REAL_TRAIN):
- **Synthetic -> Nearest REAL_TRAIN Median Distance:** `0.3702`
- **REAL_TRAIN -> Nearest Other REAL_TRAIN Median Distance:** `0.3937`
- **Minimum Observed Distance:** `0.0406`

---

## 12. Overall Findings
1. The empirical Gaussian-rank copula preserved the global and class-conditional joint probability distributions.
2. Inter-feature correlation structures exhibited minimal distortion (Frobenius norm distance < 0.15).
3. The dataset is free of duplicate records, exact training set leakage, and physical boundary violations.

---

## 13. Limitations
- **Observational Envelope:** Synthetic samples reflect the joint distributions present in the primary training dataset and TNAU/ICAR agronomic rules; they do not simulate unobserved extreme climate events beyond the calibrated bounds.
- **Parametric Non-Linearity:** Highly complex multimodal intra-crop sub-varieties are smoothed by empirical rank inversion.

---

## 14. Phase 2A Conclusion
**Does the final synthetic dataset statistically resemble the real training dataset?**
**Yes.** Comprehensive statistical testing, Wasserstein distance evaluation, correlation matrix preservation, and nearest-neighbor spatial analysis confirm that synthetic datasets faithfully reproduce the statistical properties and agricultural constraints of `REAL_TRAIN.csv`.
